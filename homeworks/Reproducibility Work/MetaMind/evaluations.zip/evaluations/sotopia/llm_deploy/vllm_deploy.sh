python -m vllm.entrypoints.openai.api_server --model ../llm_ft/vicuna-7b-1.5
