from django.apps import AppConfig


class TranslatorConfig(AppConfig):
    name = 'translator'
